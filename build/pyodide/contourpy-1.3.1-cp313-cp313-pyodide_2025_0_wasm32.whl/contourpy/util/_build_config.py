# _build_config.py.in is converted into _build_config.py during the meson build process.

from __future__ import annotations


def build_config() -> dict[str, str]:
    """
    Return a dictionary containing build configuration settings.

    All dictionary keys and values are strings, for example ``False`` is
    returned as ``"False"``.

        .. versionadded:: 1.1.0
    """
    return dict(
        # Python settings
        python_version="3.13",
        python_install_dir=r"/usr/local/lib/python3.13/site-packages/",
        python_path=r"/tmp/build-env-6_y05ten/bin/python",

        # Package versions
        contourpy_version="1.3.1",
        meson_version="1.8.3",
        mesonpy_version="0.18.0",
        pybind11_version="3.0.0",

        # Misc meson settings
        meson_backend="ninja",
        build_dir=r"/home/runner/work/pyodide-recipes/pyodide-recipes/packages/contourpy/build/contourpy-1.3.1/.mesonpy-39y7dz71/lib/contourpy/util",
        source_dir=r"/home/runner/work/pyodide-recipes/pyodide-recipes/packages/contourpy/build/contourpy-1.3.1/lib/contourpy/util",
        cross_build="True",

        # Build options
        build_options=r"-Dbuildtype=release -Db_ndebug=if-release -Db_vscrt=md -Dvsenv=True --cross-file=/home/runner/miniconda3/envs/pyodide-env/lib/python3.13/site-packages/pyodide_build/tools/emscripten.meson.cross --native-file=/home/runner/work/pyodide-recipes/pyodide-recipes/packages/contourpy/build/contourpy-1.3.1/.mesonpy-39y7dz71/meson-python-native-file.ini",
        buildtype="release",
        cpp_std="c++17",
        debug="False",
        optimization="3",
        vsenv="True",
        b_ndebug="if-release",
        b_vscrt="from_buildtype",

        # C++ compiler
        compiler_name="emscripten",
        compiler_version="4.0.9",
        linker_id="ld.wasm",
        compile_command="/home/runner/work/pyodide-recipes/pyodide-recipes/packages/contourpy/build/pywasmcross_symlinks/c++",

        # Host machine
        host_cpu="wasm",
        host_cpu_family="wasm32",
        host_cpu_endian="little",
        host_cpu_system="emscripten",

        # Build machine, same as host machine if not a cross_build
        build_cpu="x86_64",
        build_cpu_family="x86_64",
        build_cpu_endian="little",
        build_cpu_system="linux",
    )
